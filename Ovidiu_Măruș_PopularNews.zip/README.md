# Popular News

Description: native android app which displays top news fetched from NYT 

> The app uses Retrofit to make requests to NYT. It displays the fetched 
articles into a recycler view. 
